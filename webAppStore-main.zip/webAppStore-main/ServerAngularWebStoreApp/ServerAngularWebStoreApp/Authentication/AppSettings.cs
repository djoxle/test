﻿namespace ServerAngularWebStoreApp.Authentication
{
    public class AppSettings
    {
        public string Secret { get; set; }
        public string ClientEndpoint { get; set; }
    }
}