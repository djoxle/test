﻿namespace Common.DTOs
{
    public class AcceptPersonDTO
    {
        public int idPerson { get; set; }
    }
}