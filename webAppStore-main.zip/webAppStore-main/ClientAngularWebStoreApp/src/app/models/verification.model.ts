export class Verification{
    constructor(public idPerson: number, public isAccep: boolean) {}

}