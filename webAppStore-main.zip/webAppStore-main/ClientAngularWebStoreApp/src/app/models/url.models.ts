export class url
{
    url:string="";
}