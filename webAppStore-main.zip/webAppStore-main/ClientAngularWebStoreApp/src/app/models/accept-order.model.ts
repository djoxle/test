export class AcceptOrder{
    constructor(public idOrder: number, public idCustomer: number) {}

}