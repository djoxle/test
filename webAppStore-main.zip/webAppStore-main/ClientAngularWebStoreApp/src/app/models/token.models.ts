export class Token{
    id!: number;
    idPerson!: number;
    username: string = "";
    token: string = "";
    role: string = "";
    activate: string = "";
}