export class User{
    username: string | null = "";
    password: string | null = "";
}